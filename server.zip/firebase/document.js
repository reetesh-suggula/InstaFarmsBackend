const user= "Users"
const owner = "Owners"
const locations = "Locations"

module.exports = {
    user: user,
    owner:owner,
    locations:locations
}
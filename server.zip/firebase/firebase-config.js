const firebase = require('firebase');

const firebaseConfig = {
  apiKey: "AIzaSyCWzXQftelTzWUATeg4Dvxxl91-RVinNyY",
  authDomain: "instafarms-14ba5.firebaseapp.com",
  projectId: "instafarms-14ba5",
  storageBucket: "instafarms-14ba5.appspot.com",
  messagingSenderId: "571755893240",
  appId: "1:571755893240:web:0b271ef751d4e57545860d",
  measurementId: "G-DY35Y8B82L"
};

firebase.in
const express = require('express')
const router = express.Router()
const db = require('../firebase/firebase');
const { getUserDetails } = require('../models/user.model');
const { user } = require('../firebase/document');

const userCollection = db.collection(user);
// adding user to db after authentication
router.post('/addUser', async (req, res) => {
  try {
    let status = false;
    const userDetails = getUserDetails(req.body.firstName, req.body.lastName, req.body.email, req.body.phoneNumber)
    await userCollection.doc(userId).set({...userDetails, createdAt: new Date()}).then(() => {
      status = true;
    }).catch((err) => {
      status = false;
      throw err;
    })
    return res.send(status);
  } catch (err) {
    console.log(err)
    res.status(500);
  }
});

router.post('/signIn', async (req, res) => {
  try {
    let status = false;
    console.log(req.body)
    const userDetails = getUserDetails(req.body.firstName, req.body.lastName, req.body.email, req.body.phoneNumber)
    console.log(userDetails)
    await userCollection.doc(userDetails.uid).set({...userDetails, createdAt: new Date()},{ merge: true }).then(() => {
      status = true;
    }).catch((err) => {
      status = false;
      throw err;
    })
    return res.status(200).send(status);
  } catch (err) {
    console.log(err)
    res.status(500);
  }
});

module.exports = router
const express = require('express')
const router = express.Router()

router.route('/test').get((req, res) => {
    res.send('Server works!')
});

router.use('/hotelsinfo', require('./hotels.routes'));
router.use('/user', require('./user.routes'));
router.use('/owner', require('./owner.routes'));
router.use('/locations', require('./locations.routes'));
router.use('/sync', require('./sync.routes'));
router.use('/payment', require('./payment.routes'));

module.exports = router
const express = require('express')
const router = express.Router()
const db = require('../firebase/firebase');
const { locations } = require('../firebase/document');

const locationsCollection = db.collection(locations);
// adding user to db after authentication
router.get('/data', async (req, res) => {
  try {
    let locationsdata = {}
    const locations = await locationsCollection.doc('locations').get().then(doc => {
        if (!doc.exists) {
            console.log('No such document!');
        } else {
            locationsdata = doc.data();
        }
    })
    .catch(err => {
        console.error('Error getting document:', err);
    });
    return res.send(locationsdata);
  } catch (err) {
    console.log(err)
    res.status(500);
  }
});

module.exports = router
const express = require('express')
const router = express.Router()
const db = require('../firebase/firebase');
const { getOwnerDetails } = require('../models/owner.model');
const { owner } = require('../firebase/document');

const ownerCollection = db.collection(owner);
// adding user to db after authentication
router.post('/addOwner', async (req, res) => {
  try {
    const ownerDetails = getOwnerDetails(req.body.firstName, req.body.lastName, req.body.email, req.body.phoneNumber, req.body.hotelsList, req.body.address, req.body.bankDetails)
    await ownerCollection.add(ownerDetails);
    res.status(200);
  } catch (err) {
    console.log(err)
    res.status(500);
  }
});


module.exports = router